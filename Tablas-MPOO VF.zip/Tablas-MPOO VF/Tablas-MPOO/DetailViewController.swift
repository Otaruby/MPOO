//
//  DetailViewController.swift
//  Tablas-MPOO
//
//  Created by Germán Santos Jaimes on 02/03/20.
//  Copyright © 2020 iosLab. All rights reserved.
//

import UIKit

class DetailViewController: UIViewController {
    
    @IBOutlet weak var nombreProducto:UILabel!
    
    @IBOutlet weak var imagenProducto: UIImageView! 
    
    @IBOutlet weak var totalPrecio: UILabel!
    
    @IBOutlet weak var cantidad: UILabel!
    
    @IBOutlet weak var agregarButton: UIButton!
    
    
    var totalProductos = 0
    var totalPagar = 0.0
   
    
    var productoRecibido: Product!
    
    var firstView: ViewController!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        print("Producto recibido: \(productoRecibido.name)")
        cantidad.text = "0"
        totalPrecio.text = "0.0"
        imagenProducto.image = UIImage(named: productoRecibido.picture)
        nombreProducto.text = "\(productoRecibido.name)"
        imagenProducto.layer.cornerRadius = 30
    }
    
    @IBAction func addProducts(_ sender: UIStepper) {
        totalProductos = Int(sender.value)
        totalPagar = sender.value * productoRecibido.price
        
        cantidad.text = "\(totalProductos)"
        totalPrecio.text = "\(totalPagar)"
    }
    
    @IBAction func closeView(_ sender: UIButton){
        dismiss(animated: true, completion: nil)
    }
    
    @IBAction func addCar(_ sender: UIButton){
        
    firstView.agregarProductos(totalProductos: totalProductos, nombreProducto: productoRecibido.name, precioTotal: totalPagar)
            dismiss(animated: true, completion: nil)
    
    }
}
