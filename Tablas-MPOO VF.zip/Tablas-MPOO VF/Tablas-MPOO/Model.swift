//
//  Model.swift
//  Tablas-MPOO
//
//  Created by Germán Santos Jaimes on 02/03/20.
//  Copyright © 2020 iosLab. All rights reserved.
//

import UIKit

struct Product{
    var ID: UUID
    var name: String
    var picture: String
    var price: Double
    
    init(name: String, picture: String, price: Double){
        self.ID = UUID()
        self.name = name
        self.picture = picture
        self.price = price
    }
}
