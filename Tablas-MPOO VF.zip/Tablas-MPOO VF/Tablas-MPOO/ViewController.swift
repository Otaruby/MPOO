//
//  ViewController.swift
//  Tablas-MPOO
//
//  Created by Germán Santos Jaimes on 26/02/20.
//  Copyright © 2020 iosLab. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource {
    
    @IBOutlet weak var pagarButton: UIButton!
    
    @IBOutlet weak var tabla: UITableView!
    
    @IBOutlet weak var totalProductos: UILabel!
    
    @IBOutlet weak var totalPrecio: UILabel!
    
    var carrito: [(totalProductos: Int, nombreProducto: String, precioTotal: Double)] = []
    
    var products: [Product] = [
        Product(name: "Sandia", picture: "sandia", price: 30.45),
        Product(name: "Platano", picture: "platano", price: 9.90),
        Product(name: "Manzana", picture: "manzana", price: 25.50),
        Product(name: "Pera", picture: "pera", price: 23.45),
        Product(name: "Pepino", picture: "pepino", price: 13.90),
        Product(name: "Jitomate", picture: "jitomate", price: 15.50),
        Product(name: "Fresa", picture: "fresa", price: 33.80),
        Product(name: "Naranja", picture: "naranja", price: 15.90),
        Product(name: "Lechuga", picture: "lechuga", price: 15.50),
        Product(name: "Piña", picture: "piña", price: 23.45),
        Product(name: "Aguacate", picture: "aguacate", price: 32.40),
        Product(name: "Limon", picture: "limon", price: 65.60)
        
    ]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        totalProductos.text = "0"
        totalPrecio.text = "0.0"
        pagarButton.isHidden = true
        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return products.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "celda", for: indexPath)
        
        let product = products[indexPath.row]
        cell.textLabel!.text = product.name
        
        return cell
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        let indexPath = tabla.indexPathForSelectedRow
        
        if segue.identifier == "toDetail" {
            let detailView  = segue.destination as! DetailViewController
            let product = products[indexPath!.row]
            detailView.productoRecibido = product
            detailView.firstView = self
        }
    }
    
    func agregarProductos(totalProductos: Int, nombreProducto: String, precioTotal: Double){
        
        var totalItems = 0
        var totalPrecio = 0.0
        pagarButton.isHidden = false
        
        
        carrito.append((totalProductos: totalProductos, nombreProducto: nombreProducto, precioTotal: precioTotal))
        
        for producto in carrito {
            totalItems = totalItems + producto.totalProductos
            totalPrecio = totalPrecio + (producto.precioTotal * Double(producto.totalProductos))
        }
        self.totalProductos.text = "\(totalItems)"
        self.totalPrecio.text = "\(totalPrecio)"
        
    }


}

