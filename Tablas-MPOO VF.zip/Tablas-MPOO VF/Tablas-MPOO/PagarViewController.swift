//
//  PagarViewController.swift
//  Tablas-MPOO
//
//  Created by 2020-2 on 04/03/20.
//  Copyright © 2020 iosLab. All rights reserved.
//

import UIKit

class PagarViewController: UIViewController {

    
    @IBOutlet weak var pagarView: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        pagarView.layer.cornerRadius = 10
    }
    
}
